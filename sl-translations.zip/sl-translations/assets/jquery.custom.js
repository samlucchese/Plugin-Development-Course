jQuery(document).ready(function(){
	// #32. Call the .validate() method on the <form id=''> name 
	jQuery("#translations-form").validate();
	
});